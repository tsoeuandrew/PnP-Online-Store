import flet as ft
import json

def main(page: ft.Page):
    # Set page properties for mobile-like window size
    page.title = "Home Affairs"
    page.window_full_screen = True  # Enable fullscreen mode
    page.window_resizable = True  # Allow resizing

    # Feedback for different fields
    gender_feedback = ft.Text(color="red")
    nationality_feedback = ft.Text(color="red")
    names_feedback = ft.Text(color="red")
    surname_feedback = ft.Text(color="red")
    id_feedback = ft.Text(color="red")
    address_feedback = ft.Text(color="red")
    marital_feedback = ft.Text(color="red")
    feedback = ft.Text(color="red")
    day_feedback = ft.Text(color="red")
    month_feedback = ft.Text(color="red")
    year_feedback = ft.Text(color="blue")
    date_of_birth_feedback = ft.Row([day_feedback, month_feedback])

    # Clear errors when submitting the form
    def clear_feedback():
        names_feedback.value = ""
        surname_feedback.value = ""
        id_feedback.value = ""
        address_feedback.value = ""
        gender_feedback.value = ""
        nationality_feedback.value = ""
        marital_feedback.value = ""
        day_feedback.value = ""
        month_feedback.value = ""
        year_feedback.value = ""
        date_of_birth_feedback.value = ""
        feedback.value = ""  # Nationality changed handler (to show 'Other' field)

        page.update()

    # Gender dropdown
    gender_dropdown = ft.Dropdown(
        label="Gender",
        value="Please Select",  # Default value (not in options list)
        options=[
            ft.dropdown.Option("Male"),
            ft.dropdown.Option("Female")
        ],
    )

    # Nationality dropdown
    nationality_dropdown = ft.Dropdown(
        label="Nationality",
        value="Please Select",  # Default value (not in options list)
        options=[
            ft.dropdown.Option("Black"),
            ft.dropdown.Option("Coloured"),
            ft.dropdown.Option("White"),
            ft.dropdown.Option("Indian/Asian"),
            ft.dropdown.Option("Other")
        ],
    )

    # Other Nationality input (hidden by default)
    other_nationality = ft.TextField(label="Specify Other Nationality", visible=False)

    def nationality_changed(e):
        other_nationality.visible = nationality_dropdown.value == "Other"

        page.update()
    nationality_dropdown.on_change = nationality_changed

    # Marital Status dropdown
    marital_status_dropdown = ft.Dropdown(
        label="Marital Status",
        value="Please Select",  # Default value (not in options list)
        options=[
            ft.dropdown.Option("Single"),
            ft.dropdown.Option("Married"),
            ft.dropdown.Option("Divorced"),
            ft.dropdown.Option("Widowed"),
        ],
    )

    # Date of birth Dropdown option ranges
    days = [str(x) for x in range(1, 32)]  # str since options are strings, not integers
    months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    years = [str(y) for y in range(1900, 2025)]  # str since options are strings, not integers
    
    # Date of Birth dropdown
    day = ft.Dropdown(label="Day", width=120, value="Please Select", options=[ft.dropdown.Option(day) for day in days])
    month = ft.Dropdown(label="Month", width=150, value="Please Select", options=[ft.dropdown.Option(month) for month in months])
    year = ft.Dropdown(label="Year", width=150, value="Please Select", options=[ft.dropdown.Option(year) for year in years])
    
    date_of_birth = ft.Row([day, ft.Text("/"), month],alignment=ft.MainAxisAlignment.CENTER)  # not using ft.text gives error
    date_of_birth_label = ft.Text("Date of Birth", size=20, weight="bold")

    # Create Text fields
    names = ft.TextField(label="Names")
    surname = ft.TextField(label="Surname")
    id_number = ft.TextField(label="Enter ID Number", autofocus=True)
    address = ft.TextField(label="Physical Address", height=100, multiline=True)
    
    def error_handler(e):
        clear_feedback()  # Clear previous feedback
        has_errors = False  # Flag to track errors

        try:
            # Validate Names
            if not names.value.strip():  # Check if the names field is empty
                names_feedback.value = "Names cannot be empty."
                has_errors = True
            elif not names.value.replace(" ", "").isalpha():
                names_feedback.value = "Names must only contain alphabetic characters."
                has_errors = True

            # Validate Surname
            if not surname.value.strip():  # Check if the surname field is empty
                surname_feedback.value = "Surname cannot be empty."
                has_errors = True
            elif not surname.value.isalpha():
                surname_feedback.value = "Surname must only contain alphabetic characters."
                has_errors = True

            # Validate ID Number
            id_number_cleaned = id_number.value.strip()
            if not id_number_cleaned.isdigit() or len(id_number_cleaned) != 13:
                id_feedback.value = "ID Number must be 13 digits long and numeric."
                has_errors = True

            # Validate Gender selection
            if gender_dropdown.value == "Please Select":
                gender_feedback.value = "Please select a Gender."
                has_errors = True

            # Validate Date of Birth
            if day.value == "Please Select":
                day_feedback.value = "Please select a day."
                has_errors = True
            if month.value == "Please Select":
                month_feedback.value = "Please select a month."
                has_errors = True
            if year.value == "Please Select":
                year_feedback.value = "Please select a year."
                has_errors = True  

             # Validate Nationality selection
            if nationality_dropdown.value == "Please Select":
                nationality_feedback.value = "Please select a Nationality."
                has_errors = True

            # If "Other" is selected for Nationality, ensure it's filled
            if nationality_dropdown.value == "Other" and not other_nationality.value.strip():
                nationality_feedback.value = "Please specify your nationality if 'Other' is selected."
                has_errors = True

            # Validate Marital Status selection
            if marital_status_dropdown.value == "Please Select":
                marital_feedback.value = "Please select a Marital Status."
                has_errors = True

            # Validate Physical Address
            if not address.value.strip():
                address_feedback.value = "Physical Address cannot be empty."
                has_errors = True

        except Exception as e:
            feedback.value = f"Unexpected Error: {str(e)}"
            has_errors = True  # Mark an error occurred

        finally:
            page.update()

        return has_errors  # Return True if errors exist, False otherwise # Check if the user has entered a valid name
        










    # Save data to a JSON file
      # Save data to a JSON file
    def save_data(e):
        if error_handler(e):  # Check for errors
            return  # Don't save if there are errors
        user_data = "data.json"

        # Prepare the user data to be saved as a dictionary
        info = {
            "Names": names.value,
            "Surname": surname.value,
            "ID Number": id_number.value,
            "Date of Birth": f"{day.value}/{month.value}/{year.value}",
            "Gender": gender_dropdown.value,
            "Nationality": nationality_dropdown.value,
            "Marital Status": marital_status_dropdown.value,
            "Physical Address": address.value
        }

        try:
            # Step 1: Read existing data from the file
            try:
                with open(user_data, 'r') as file:  # Open the file in read mode
                    data = json.load(file)  # Load existing JSON data
            except (FileNotFoundError, json.JSONDecodeError):
                data = []    #If file doesn't exist or is invalid, initialize an empty list
            
            data.append(info)  # Append the new user info to the list
            with open(user_data, 'w') as file:  # Open the file and rewrite the updated data
                json.dump(data, file, indent=4)  # Save the list with indentation for readability
            feedback.value = "Data saved successfully!"  # Success feedback

        except Exception as e:
            feedback.value = f"Error saving data: {str(e)}"  # Error feedback

        finally:
            page.update()  # Update the page to reflect the feedback

    def search_id(e):
        with open("data.json", "r") as file:
            data = json.load(file)
            id = id_number.value
            if id in data:
                names.value = data[id]["names"]
                surname.value = data[id]["surname"]
                address.value = data[id]["address"]
            
    def print_data(e):
        with open("data.json", "r") as file:
            data = json.load(file)
            print(data)

    # Submit Button
    Save_button = ft.ElevatedButton(text="Save", on_click=save_data)
    print_button = ft.ElevatedButton(text="print", on_click=print_data)
    search_button = ft.ElevatedButton("Search", on_click=search_id)

     # Add controls to the page with the desired layout (left-aligned and right-aligned sections)
    page.add(
    ft.Row([
        ft.Column([  # Left side column
            id_number,
            id_feedback,
            names,
            names_feedback,
            surname,
            surname_feedback,
            address,
            address_feedback,
            date_of_birth_label,
            date_of_birth,date_of_birth_feedback,
            year,year_feedback
        ], width=200),  # Adjust width to control space

        # Right side column (gender, marital status, nationality, and other nationality)
        ft.Column([
            ft.Column([gender_dropdown, gender_feedback]),
            ft.Column([marital_status_dropdown, marital_feedback]),
            ft.Column([nationality_dropdown, nationality_feedback]),
            ft.Column([other_nationality]),
        ]),
    ]),  # Close Row list

    ft.Row([Save_button, search_button,print_button],width=200) ,# Add the buttons to the page
    feedback
)
    
# Run the app
ft.app(target=main)